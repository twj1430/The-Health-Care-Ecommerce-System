﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace PaymentLibrary
{
    public class objPayment
    {
        public string CID { get; set; }
        public string OrderRef { get; set; }
        public string defaultbanknumber { get; set; }
        public string version { get; set; }
        public string v_currency { get; set; }
        public string v_amount { get; set; }
        public string v_firstname { get; set; }
        public string v_lastname { get; set; }
        public string v_billemail { get; set; }
        public string v_billstreet { get; set; }
        public string v_billcity { get; set; }
        public string v_billstate { get; set; }
        public string v_billpost { get; set; }
        public string v_billcountry { get; set; }
        public string v_billphone { get; set; }
        public string v_shipstreet { get; set; }
        public string v_shipcity { get; set; }
        public string v_shipstate { get; set; }
        public string v_shippost { get; set; }
        public string v_shipcountry { get; set; }
        public string v_shipphone { get; set; }

        public string signaturekey { get; set; }
        public string signature { get; set; }
        public string v_cartid { get; set; }
        public string callbackurl { get; set; }
        public string returnurl { get; set; }
        public string clientip { get; set; }

        public string v_productno { get; set; }
        public string v_productcode { get; set; }
        public string v_productdesc { get; set; }
        public string v_productqty { get; set; }
        public string v_productunitprice { get; set; }
        public string v_productpricecurrency { get; set; }
        public string v_subamount { get; set; }

        //Credit Card
        public string v_cardholder { get; set; }
        public string v_cardholder_last { get; set; }
        public string v_cardnum { get; set; }
        public string v_month { get; set; }
        public string v_year { get; set; }
        public string v_cvv2 { get; set; }
        public string v_pmode { get; set; }

        //Recurring
        public string epkey { get; set; }
        public string recurringtype { get; set; }

        //WECHAT QUICKPAY
        public string wechatauthcode { get; set; }

        //INTERNET BANKING
        public string ebankid { get; set; }
        public bool PostType {get;set;}

        // PRESELECTION
        public string preselection { get; set; }

        // FOR REPORTING
        public string terminalid { get; set; }

        public SelectList CountryList;
    }
}
