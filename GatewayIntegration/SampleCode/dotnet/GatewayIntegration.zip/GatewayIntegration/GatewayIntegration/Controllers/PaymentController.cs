﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PaymentLibrary;
namespace GatewayIntegration.Controllers
{
    public class PaymentController : Controller
    {
        public ActionResult Index()
        {
            objPayment objPayment = new objPayment();
            ClassFunction classFunction = new ClassFunction();
            objPayment.CID = "M161-U-XXX";
            objPayment.signaturekey = "abcd1234";
            objPayment.v_cartid = DateTime.Now.ToString("yyyyMMddHHmmss");
            objPayment.v_currency = "MYR";
            objPayment.v_amount = "10.00";
            objPayment.v_firstname = "Merchant";
            objPayment.v_lastname = "Integration";
            objPayment.v_billemail = "int@example.com";
            objPayment.v_billstreet = "1 Street Two";
            objPayment.v_billpost = "12345";
            objPayment.v_billcity = "Three City";
            objPayment.v_billstate = "Four State";
            objPayment.v_billphone = "0123456789";
            objPayment.CountryList = classFunction.GetCountryList();
            return View(objPayment);
        }

        [HttpPost]
        public ActionResult Submit(objPayment objPayment)
        {
            ClassFunction lib = new ClassFunction();
            string response = "";
            try
            {
                if (objPayment.PostType)
                {
                    response = lib.HostToHost(objPayment);
                }
                else
                {
                    response = lib.WebToWeb(objPayment);
                }
            }
            catch (Exception)
            {

                throw;
            }
            

            return Content(response);
        }
    }
}